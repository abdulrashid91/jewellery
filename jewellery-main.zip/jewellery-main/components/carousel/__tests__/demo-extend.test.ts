import { extendTest } from '../../../tests/shared/demoTest';

extendTest('carousel');
