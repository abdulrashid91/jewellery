import byBY from '../../date-picker/locale/by_BY';

export default byBY;
