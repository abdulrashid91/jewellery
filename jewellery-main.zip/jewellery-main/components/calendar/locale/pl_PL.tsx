import plPL from '../../date-picker/locale/pl_PL';

export default plPL;
