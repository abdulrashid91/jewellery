import srRS from '../../date-picker/locale/sr_RS';

export default srRS;
