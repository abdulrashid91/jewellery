import taIN from '../../date-picker/locale/ta_IN';

export default taIN;
