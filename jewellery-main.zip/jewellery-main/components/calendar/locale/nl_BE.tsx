import nlBE from '../../date-picker/locale/nl_BE';

export default nlBE;
