import zhTW from '../../date-picker/locale/zh_TW';

export default zhTW;
