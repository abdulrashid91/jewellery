import kaGE from '../../date-picker/locale/ka_GE';

export default kaGE;
