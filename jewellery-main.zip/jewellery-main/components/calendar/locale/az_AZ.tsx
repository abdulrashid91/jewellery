import azAZ from '../../date-picker/locale/az_AZ';

export default azAZ;
