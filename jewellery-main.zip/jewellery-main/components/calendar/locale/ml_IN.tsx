import mlIN from '../../date-picker/locale/ml_IN';

export default mlIN;
