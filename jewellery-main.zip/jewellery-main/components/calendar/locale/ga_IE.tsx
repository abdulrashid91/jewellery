import gaIE from '../../date-picker/locale/ga_IE';

export default gaIE;
