import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Calendar image', () => {
  imageDemoTest('calendar');
});
