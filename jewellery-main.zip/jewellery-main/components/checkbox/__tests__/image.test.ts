import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Checkbox image', () => {
  imageDemoTest('checkbox');
});
