import { extendTest } from '../../../tests/shared/demoTest';

extendTest('date-picker', { skip: ['locale.md'] });
