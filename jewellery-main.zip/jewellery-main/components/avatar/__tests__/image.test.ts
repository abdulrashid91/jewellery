import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Avatar image', () => {
  imageDemoTest('avatar');
});
