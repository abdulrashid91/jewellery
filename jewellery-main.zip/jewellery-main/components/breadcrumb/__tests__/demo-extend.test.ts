import { extendTest } from '../../../tests/shared/demoTest';

extendTest('breadcrumb', { skip: ['react-router.md'] });
