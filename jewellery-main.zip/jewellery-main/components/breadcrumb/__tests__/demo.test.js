import demoTest from '../../../tests/shared/demoTest';

demoTest('breadcrumb', { skip: ['react-router.md'] });
