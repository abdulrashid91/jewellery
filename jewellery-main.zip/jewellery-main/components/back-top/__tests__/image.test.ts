import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('BackTop image', () => {
  imageDemoTest('back-top');
});
