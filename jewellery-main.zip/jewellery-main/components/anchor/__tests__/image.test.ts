import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Anchor image', () => {
  imageDemoTest('anchor');
});
