import demoTest from '../../../tests/shared/demoTest';

demoTest('auto-complete');
