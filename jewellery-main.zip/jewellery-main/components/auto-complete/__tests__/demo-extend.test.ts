import { extendTest } from '../../../tests/shared/demoTest';

extendTest('auto-complete');
