import { imageDemoTest } from '../../../tests/shared/imageTest';

describe('Comment image', () => {
  imageDemoTest('comment');
});
